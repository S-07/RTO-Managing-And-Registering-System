package com.rtofinalproject.registrations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationsApplication.class, args);
	}

}
